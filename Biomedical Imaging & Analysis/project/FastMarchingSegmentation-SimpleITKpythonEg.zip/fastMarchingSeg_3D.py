# -*- coding: cp936 -*-
'''=========================================================================

  For trial point, it still should be inside the target, so here I take (30, 31, 40) as trial point.

  Alpha = -0.528, the result segmented tube has many little holes and fractures around it. alpha = -0.5
  or some other number doesn't change too much. alpha = -0.5 is the final one that I chose.

  Beta = 11.5, the result segmented tube has many little holes and fractures around it. when beta=7, more
  holes and fractures. As beta decreases from 11 to 1 , the result is more bad. The final beta=10

  Upper threshold is 255. Actually there is no significant change when upper threshold reaches 200.

  Sigma = 0.4 or sigma = 0.5 does not make things better. Sigma = 1 makes the result better, so final sigma = 1.

  Rate = 5, because the segmentation is not very good.
 
 '========================================================================='''

from __future__ import print_function

import SimpleITK
import sys

if __name__ == '__main__':
  
  #
  # Check Command Line
  #
  if len( sys.argv ) < 5:
    print("Usage: fastMarchingseg_3D.py inputImage outputImage alpha beta ");
    sys.exit( 1 )
  
  
  #
  # Read the image
  #
  reader = SimpleITK.ImageFileReader()
  reader.SetFileName( sys.argv[1] )
  image = reader.Execute();
  
  #
  # Set up the writer
  #
  writer = SimpleITK.ImageFileWriter()
  writer.SetFileName( sys.argv[2] )
  
  #
  # Blur using CurvatureFlowImageFilter
  #
  blurFilter = SimpleITK.CurvatureFlowImageFilter()
  blurFilter.SetNumberOfIterations( 5 )
  blurFilter.SetTimeStep( 0.125 )
  image = blurFilter.Execute( image )

  #
  # gradientMagnitude
  #

  graMag=SimpleITK.GradientMagnitudeRecursiveGaussianImageFilter()
  graMag.SetSigma( 1 )
  image= graMag.Execute (image)

  #
  # sigmoid
  #
  sigM=SimpleITK.SigmoidImageFilter()
  sigM.SetAlpha( float (sys.argv[3]) )
  sigM.SetBeta( float (sys.argv[4]) )
  sigM.SetOutputMaximum( 255)
  sigM.SetOutputMinimum(0)
  image=sigM.Execute(image)

  #
  # fastMarching
  #
  fasM=SimpleITK.FastMarchingImageFilter()
  fasM.SetNormalizationFactor( 1.0 )
  fasM.SetTrialPoints([(30,31,40)])
  fasM.SetStoppingValue( 100.0)
  image=fasM.Execute(image)

  #
  # Set up  for BinaryThresholdImageFilter segmentation
  #
  segmentationFilter = SimpleITK.BinaryThresholdImageFilter()
  segmentationFilter.SetLowerThreshold( 0 )
  segmentationFilter.SetUpperThreshold( 255 )
  segmentationFilter.SetInsideValue( 255 )
  segmentationFilter.SetOutsideValue( 0 )
  
  
  # Run the segmentation filter
  image = segmentationFilter.Execute( image )
  
  #
  # Write out the result
  #
  writer.Execute( image )
  
  sys.exit(0)
  
  
  
  

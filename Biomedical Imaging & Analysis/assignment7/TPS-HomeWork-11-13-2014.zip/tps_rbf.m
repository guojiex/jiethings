function result = tps_rbf(r) 

%NOTE: 'r' here is the position vector of a point on the image, relative to
%an origin define by one of the landmark points, pi i.e. norm(X - pi),
%where X is [x, y] of of an image pixel position.

ww = find(r == 0);
result = (r.^2).*log(r.^2);
result(ww) = 0;
close all;clear;clc;

%% Test image -- Replace these with an image of your face and the image of your favorite animal, respectively:
N = 256;
img_src = zeros(N,N);
img_trg = zeros(N,N);
img_src(N/2-20:N/2+20,N/2-20:N/2+20) = 1;
img_trg(N/2-80:N/2+80,N/2-80:N/2+80) = 1;

figure(1);imagesc(img_src);colormap gray;truesize
figure(2);imagesc(img_trg);colormap gray;truesize

%% Select corresponding points using "cpselect" function
[input_points,base_points]=cpselect(img_src,img_trg,'wait',logical(1));

PY = input_points';
PX = base_points';

%% Compute Transformation parameters: "W" matrix , based on selected point correspondences
Npts = size(PX,2);
PHI = zeros(Npts,Npts);
for i=1:Npts
    for j = 1:Npts        
        PHI(i,j) = %..? tps_rbf(???)
    end
end

LAMBDA = [ones(Npts,1),PX'];
K = %..?
D =  %..? Input points matrix - remember to "pad" it with zeroes appropriately!
W = %..?

%% Apply the computed transformation parameters in "W" to move all the source image points to their new positions
[X,Y] = meshgrid(1:size(img_src,2),1:size(img_src,1));  % positions of the pixels of the images

% Evaluate translation plus rotation applied to the image positions
tmp_fx = %translation in x + rotation applied to X coordinate 
tmp_fy = %translation in x + rotation applied to Y coordinate 

% Evaluate Thin Plate Spline related movement
for k=1:Npts
    Xt = X - PX(1,k);
    Yt = Y - PX(2,k);
    tmp_fx = %..?  tmp_fx + ??*tps_rbf(??? - some function of Xt and Yt!);
    tmp_fy = %..?
end

%% Map intensity information from original image to warped point positions
result = interp2(img_src,tmp_fx,tmp_fy,'linear',0);
figure(3);imagesc(result);colormap gray;truesize

%% Visualize the transformation at a point by point level using a virtual "Grid"
% Make a virtual grid image of the same size as your Source Image.
grid_img = img_trg*0;
grid_img(1:15:size(grid_img,1),:) = 1;
grid_img(:,1:15:size(grid_img,1)) = 1;
Z = ones(3,3);
Z = Z./(sum(sum(Z)));
grid_img = conv2(grid_img,Z,'same');

% map the grid image to the warped point positions
result_grid = interp2(grid_img,tmp_fx,tmp_fy,'linear',0);

% Visualize the transformation you created!
figure(4)
subplot(1,2,1)
imagesc(result_grid);colormap gray; axis equal; axis off; %truesize
subplot(1,2,2)
imagesc((X-tmp_fx).^2+(Y-tmp_fy).^2); colormap gray; axis equal; axis off; %truesize
title({'Magnitude of vector displacement of'; 'source points to their final positions'});
colorbar

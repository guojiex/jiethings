%Polynomial least squares curve fitting - First and Second order curve fitting.
%All the given data points must be used for fitting.

clear; clc; close all;

load('HW1_Part2Q1.mat'); %loads the variable f(x) into the workspace
N = numel(f); %number of discrete points on f(x). f is a column vector
xi = [1:1:N]';
FittedResult = zeros(N,1);

n = input('Enter order of fitting polynomial (1 = linear, 2 = quadratic)  :    ');

A = zeros(n+1,n+1);
b = zeros(n+1,1);
Coeffs = zeros(n+1,1);%these are the fitting coefficients: a, b, c, etc.

% linear system: Ax = b and x = A\b

for u = 1:1:n+1
    for v = 1:1:n+1
%        A(u,v) = ???   ------------------------------------ fill this in!
    end
%          b(u) = ???   ------------------------------------ fill this in!
end

Coeffs = A\b;

for u = 1:1:n+1
%    FittedResult = FittedResult + ??  ---------------------- fill this in!
end

%Plot the fit and the original data set
plot(xi,f,'r*');
hold on;
plot(xi, V,'g-','LineWidth',3)